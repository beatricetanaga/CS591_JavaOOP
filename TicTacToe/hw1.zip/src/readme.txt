Tic-Tac-Toe Game Program Instructions

How to run the program:
1. Go to terminal and navigate to src folder
2. type "javac Game.java"
3. type "java Game"
4. Game will initiate and you're ready to play! 

How to play:
Please type in two numbers (ex. 1 2) corresponding to the row and column where you would like to place your next move, then hit enter. Rows and columns are labeled on the board for your convenience. If an invalid input is given, game will not proceed and will wait for a valid input to be typed in. 
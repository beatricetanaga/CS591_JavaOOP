/*
 * Checkers to be used in the games
 */

public enum Checker {
	EMPTY, X, O;
}

/*
 * gameState keeps track of the progress of each game
 */

public enum gameState {
	inProgress, tie, xHasWon, oHasWon, orderHasWon, chaosHasWon;
}
